Thank you for downloading Blockly and for participating in the Hour of Code.

To use Blockly, point a modern web browser at the file "index.html" in this
directory.

You can ask questions about Blockly in the discussion group at:
"https://groups.google.com/forum/#!forum/blockly".
